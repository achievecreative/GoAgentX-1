#!/usr/bin/env python
# coding:utf-8

def main():
    import appcfg
    appcfg.main()

if __name__ == '__main__':
   try:
       main()
   except KeyboardInterrupt:
       pass